// #ifndef CANVASBACK
// #define CANVASBACK
// #include "duck.h"
// class Canvasback : public Duck {
//     public:
//         void quack();
//         void display();
//         void fly();
// };
// #endif
#include "canvasback.h"
void Canvasback::display(){
    cout << "I am a Canvasback duck!" << endl;
}
void Canvasback::quack(){
    cout << "Quack!" << endl;
}
void Canvasback::fly(){
    cout <<"I can fly!" << endl;
}