#ifndef MALLARD
#define MALLARD
#include "duck.h"
class Mallard : public Duck {
    public:
        void quack();
        void display();
        void fly();
};
#endif