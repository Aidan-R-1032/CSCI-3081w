/**
Part A

Prompt: We have given you specifications for a Duck class that has a few attributes (shown below).
Your job is to complete the Duck class and
finish the main method so that the ducks get ordered based on their coolness.
Hint: Look at C++ standard library sort function

DUCK:

variables:
1. name: string - the name of the duck
2. coolness: float - how cool the duck is (float from 1-10)
3. weight: double - average weight of the duck in pounds

functions:
1. default constructor
2. constructor with paramaters
3. getName: returns string
4. getCoolness: returns float
5. getWeight: returns double
*/

/**
Part B

Add the big three to your Duck class: destructor, copy constructor, copy assignment operator.
Add comments explaining what each one does, how they differ from one other, 
and differences between each of these and the default constructor.
*/

/**
Part C

We will now refactor our Duck class to be an abstract parent class (Duck) with child classes (Mallard, Canvasback, and Rubber).
    Each class should be its own file (duck.cc, mallard.cc, canvasback.cc, and rubber.cc)
The parent class will have the following pure virtual methods added:
    quack: void
    display: void
    swim: void
    fly: void
The child classes have the following behavior:
    Mallard
        quack: prints “Quack!”
        display: prints “I am a Mallard Duck!”
        swim: prints “I can swim!”
        fly: prints “I can fly!”
    Canvasback
        quack: prints “Quack!”
        display: prints “I am a Canvasback Duck!”
        swim: prints “I can swim!”
        fly: prints “I can fly!”
    Rubber
        quack: prints “Squeak!”
        display: prints “I am a Rubber Duck!”
        swim: prints “I can swim!”
        fly: prints “I can’t fly!”
1. One of these four added functions can be refactored such that it is not pure virtual anymore. Refactor that function accordingly.
2. Create an instance of each of the children classes in the main function.
3. You'll also have to comment out the ducks vector, all the push_backs, and sort from part A.
Why?
[Response here]
*/
    //They need to be commented out because there are some purely virtual functions- hence why 
    //an instance of duck cannot be created
/**
Part D

Create five functions that take in two ducks and output something. 
You get to define the functions however you want. 
Feel free to add new variables to the ducks in order to complete wanted functionality. 
In addition to writing the code, comments are required. 
Comments should not only detail the logic behind the code, 
but also explain how the different classes and methods interact to create an interesting experience. 
In the main method, demonstrate each one of your five functions in action.
This is your chance to have fun!

*/
#include "duck.h"
// TODO part A: Duck class goes here
Duck::Duck(){
    name = "NA";
    coolness = 0;
    weight = 0.0;
    parent_1 = nullptr;
    parent_2 = nullptr;
}
Duck::Duck(string duckName, float duckCoolness, double duckWeight){
    name = duckName;
    coolness = duckCoolness;
    weight = duckWeight;
    parent_1 = nullptr;
    parent_2 = nullptr;
}
string Duck::getName(){
    return name;
}
float Duck::getCoolness(){
    return coolness;
}
double Duck::getWeight(){
    return weight;
}
// TODO part B: add the big three
// A destructor is a class member function that is automatically called when an object of the class is destroyed
Duck::~Duck(){
    cout << "Deallocating duck object: " << name << "(coolness: " << coolness << ", weight: " << weight << ")" << endl;
}
// A copy constructor is another version of a constructor that can be called with a single pass by reference argument
Duck::Duck(const Duck& originalDuck){
    name = originalDuck.name;
    coolness = originalDuck.coolness;
    weight = originalDuck.weight;
    parent_1 = originalDuck.parent_1;
    parent_2 = originalDuck.parent_2;
}
//The assignment operator "=" can be overloaded for a class via a member function, 
//known as the copy assignment operator, that overloads the built-in function "operator=", 
//the member function having a reference parameter of the class type and returning a 
//reference to the class type.
Duck& Duck::operator=(const Duck& originalDuck){
    if(this != &originalDuck){
        name = originalDuck.name;
        coolness = originalDuck.coolness;
        weight = originalDuck.weight;
        parent_1 = originalDuck.parent_1;
        parent_2 = originalDuck.parent_2;
    }
    return *this;
}
bool Duck::operator>(const Duck& originalDuck){
    return coolness > originalDuck.coolness;
}
void Duck::swim(){
    cout << "I can swim!" << endl;
}
// TODO part C: refactor Duck class and create a few new classes (separate files)
// TODO part D: 5 added functions and corresponding comments go here (or in your child class files depending on how you want to implement it)

//mate: returns a new duck with average coolness and weight, name of duck is "Jr."
Duck& Duck::mate(Duck& duck_1, Duck& duck_2){
    if(this != &duck_1 && this != &duck_2){
        double average_weight = (duck_1.weight + duck_2.weight) / 2;
        double average_coolness = (duck_1.coolness + duck_2.coolness) / 2;
        this->name = "Jr";
        this->coolness = average_coolness;
        this->weight = average_weight;
        this->parent_1 = &duck_1;
        this->parent_2 = &duck_2;
    }
    return *this;
}
//setters used in main
void Duck::setName(string new_name){
    this->name = new_name;
}
void Duck::setWeight(double new_weight){
    this->weight = new_weight;
}
void Duck::setCoolness(double new_coolness){
    this->coolness = new_coolness;
}
void Duck::setParent_1(Duck* parent){
    if(parent != nullptr){
        this->parent_1 = parent;
    }
}
void Duck::setParent_2(Duck* parent){
    if(parent != nullptr){
        this->parent_2 = parent;
    }
}
//display_mate- performs mate & outputs statistics
Duck& Duck::display_mate(Duck& duck_1, Duck& duck_2){
    *this = mate(duck_1, duck_2);    
    cout << this->name << " is the offspring of " << duck_1.name << "and " << duck_2.name << "." << endl;
    cout << duck_1.name << ": (weight: " << duck_1.weight << ", coolness: " << duck_1.coolness << ")" << endl;
    cout << duck_2.name << ": (weight: " << duck_2.weight << ", coolness: " << duck_2.coolness << ")" << endl;
    cout << this->name << ": (weight: " << this->weight << ", coolness: " << this->coolness << ")" << endl;
    return *this;
}
//is_parents- determines if the following ducks are parents of the current duck
bool Duck::is_parents(Duck& duck_1, Duck& duck_2){
    bool duck_1_related;
    bool duck_2_related;
    if(this->parent_1 == nullptr || this->parent_2 == nullptr){
        return false;
    }
    duck_1_related = ((parent_1 == &duck_1) || (parent_2 == &duck_1));
    duck_2_related = ((parent_1 == &duck_2) || (parent_2 == &duck_2));
    return duck_1_related && duck_2_related;
}
//is_grandparents- determines if the following ducks are grandparents of the current duck
bool Duck::is_grandparents(Duck &duck_1, Duck& duck_2){
    return parent_1->is_parents(duck_1, duck_2) || parent_2->is_parents(duck_1, duck_2);
}
//adopt_if_orphan- "adopts" the current duck and sets their parents to the following ducks
void Duck::adopt_if_orphan(Duck& duck_1, Duck& duck_2){
    if(parent_1 == nullptr && parent_2 == nullptr){
        parent_1 = &duck_1;
        parent_2 = &duck_2;
    }
}