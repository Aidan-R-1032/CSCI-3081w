#ifndef RUBBER_DUCK
#define RUBBER_DUCK
#include "duck.h"
class Rubber : public Duck {
    public:
        void quack();
        void display();
        void fly();
};
#endif