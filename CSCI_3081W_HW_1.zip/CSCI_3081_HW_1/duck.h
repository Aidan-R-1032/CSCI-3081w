#ifndef DUCK
#define DUCK
using namespace std;
#include <string>
#include <vector>
#include <iostream>
class Duck{
    public:
        Duck();
        Duck(string duckName, float duckCoolness, double duckWeight);
        string getName();
        float getCoolness();
        double getWeight();
        ~Duck();
        Duck(const Duck& originalDuck);
        Duck& operator=(const Duck& originalDuck);
        bool operator>(const Duck& originalDuck);
        virtual void quack() = 0;
        virtual void display() = 0;
        void swim();
        virtual void fly() = 0;
        Duck& mate(Duck& duck_1, Duck& duck_2);//returns a new duck with average coolness and weight, name of duck is "jr."
        Duck& display_mate(Duck& duck_1, Duck& duck_2);//performs mate and displays duck info
        void adopt_if_orphan(Duck& duck_1, Duck& duck_2);//if the duck has no parents, update parents with these ducks
        bool is_parents(Duck& duck1, Duck& duck_2);//determines if the BOTH provided ducks are the parents
        bool is_grandparents(Duck& duck_1, Duck& duck_2);//determines if BOTH provided ducks are parents of the current ducks's parent
        void setName(string new_name);
        void setWeight(double new_weight);
        void setCoolness(double new_coolness);
        void setParent_1(Duck* parent);
        void setParent_2(Duck* parent);
    protected:
        string name;
        float coolness;
        double weight;
        //added parameters:
        Duck *parent_1;
        Duck *parent_2;
};
#endif