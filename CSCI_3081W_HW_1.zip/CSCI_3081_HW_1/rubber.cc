// #ifndef RUBBER_DUCK
// #define RUBBER_DUCK
// #include "duck.h"
// class Rubber : public Duck {
//     public:
//         void quack();
//         void display();
//         void fly();
// };
// #endif
#include "rubber.h"
void Rubber::display(){
    cout << "I am a Rubber duck!" << endl;
}
void Rubber::quack(){
    cout << "Squeak!" << endl;
}
void Rubber::fly(){
    cout <<"I can't fly!" << endl;
}
