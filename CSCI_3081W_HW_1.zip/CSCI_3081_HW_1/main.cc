#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
// #include "duck.cc"
#include "mallard.h"
#include "rubber.h"
#include "canvasback.h"

// bool compareDucks (Duck* a_duck, Duck* b_duck)
// {
//     return (a_duck->getCoolness()) > (b_duck->getCoolness());
// }
int main()
{
    // std::vector<Duck> ducks;
    // ducks.push_back(Duck(std::string("Fulvous Whistling Duck"), 8.6f, 1.6));
    // ducks.push_back(Duck(std::string("Domestic Duck"), 2.5f, 2.5));
    // ducks.push_back(Duck(std::string("CanvasBack"), 5.8f, 2.7));
    // ducks.push_back(Duck(std::string("Loon"), 10.0f, 10.0));
    // ducks.push_back(Duck(std::string("Mallard"), 7.6f, 2.5));
    // std::sort(ducks.begin(), ducks.end(), compareDucks);

    // TODO part A: sort the ducks based on coolness
    // Note: You may want to double check your work here by printing to standard output

    // for(int i = 0; i < ducks.size(); i++){
    //     Duck &currDuck = ducks.at(i);
    //    cout << currDuck.getName() << "Duck coolness: " << currDuck.getCoolness() << endl;
    // }

    // TODO part C: Create an instance of each of the children classes in the main function.
    // TODO part C: Comment out the ducks vector, all the push_backs, and sort from part A.
    
    Mallard *mallard_duck = new Mallard();
    mallard_duck->display();
    mallard_duck->quack();
    mallard_duck->swim();
    mallard_duck->fly();
    Canvasback *cback_duck = new Canvasback();
    cback_duck->display();
    cback_duck->quack();
    cback_duck->swim();
    cback_duck->fly();
    Rubber *rubber_duck = new Rubber();
    rubber_duck->display();
    rubber_duck->quack();
    rubber_duck->swim();
    rubber_duck->fly();

    
    // TODO part D: Demonstrate each one of your five defined functions.
    cout << endl;
    // Below demonstrates the base of mate, notice how annoying it is to print everything
    cout << "This demonstrates mate:" << endl;
    Duck *father = new Mallard();
    father->setName("Don");
    father->setCoolness(10.0);
    father->setWeight(12.7);
    Duck *mother = new Mallard();
    mother->setName("Daisy");
    mother->setCoolness(8.7);
    mother->setWeight(11.3);
    Duck *child = new Mallard();
    child->mate(*father, *mother);
    child->display();
    cout<< child->getName() <<" is the offspring of " << father->getName() << " and " << mother->getName() << "."<< endl;
    cout<< father->getName() << ": (coolness: " << father->getCoolness() << ", weight:" << father->getWeight() << ")" << endl;
    cout<< mother->getName() << ": (coolness: " << mother->getCoolness() << ", weight:" << mother->getWeight() << ")" << endl;
    cout<< child->getName() << ": (coolness: " << child->getCoolness() << ", weight:" << child->getWeight() << ")" << endl;
    cout << endl;
    //Below demonstrates the display_mate, notice how it prints everying about the child and parents
    cout << "This demonstrates display_mate:" << endl;
    child->display_mate(*father, *mother);
    cout << endl;
    //Below demonstrates the is_parents function, it only returns true if both ducks are the parents
    cout << "This demonstrates is_parents" << endl;
    cout << "Jr is the child of Don & Daisy (1: true, 0: false): " << child->is_parents(*father, *mother) << endl;
    cout << "Daisy is the child of Don & Jr (1: true, 0: false): " << mother->is_parents(*child, *father) << endl;
    cout << "Don is the child of Jr & Daisy (1: true, 0: false): "<< father->is_parents(*child, *mother) << endl;
    cout << endl;
    //Below demonstrates the is_grandparent function
    cout << "This demonstrates the is_grandparents fucntion" << endl;
    Duck *grandfather = new Mallard();
    grandfather->setName("Donald");
    Duck *grandmother = new Mallard();
    grandmother->setName("Dawn");
    Duck *Gerry = new Mallard();
    Gerry->setName("Gerry");
    Duck *Sue = new Mallard();
    Sue->setName("Sue");
    father->setParent_1(grandfather);
    father->setParent_2(grandmother);
    cout << "Jr is the grandchild of Donald & Dawn (1: true, 0: false): " << child->is_grandparents(*grandfather, *grandmother) << endl;
    cout << "Jr is the grandchild of Gerry & Sue (1: true, 0: false): " << child->is_grandparents(*Gerry, *Sue) << endl;
    cout << "Don is the grandchild of Donald & Dawn (1: true, 0: false): " << father->is_grandparents(*grandfather, *grandmother) << endl;
    cout << endl;
    //Below demonstrates the adopt_if_orphan function: 
    cout << "This demonstrates the adopt_if_orphan function: " << endl;
    father->adopt_if_orphan(*Sue, *Gerry);
    cout << "Don is the child of Sue & Gerry (1: true, 0: false): "<< father->is_parents(*Sue, *Gerry) << endl;
    cout << "Daisy is the child of Sue & Gerry (1: true, 0: false): "<< mother->is_parents(*Sue, *Gerry) << endl;
    cout << "Daisy is now adopted by Sue & Gerry." << endl;
    mother->adopt_if_orphan(*Sue, *Gerry);
    cout << "Daisy is the child of Sue & Gerry (1: true, 0: false): "<< mother->is_parents(*Sue, *Gerry) << endl;
    cout << "Jr is the grandchild of Gerry & Sue (1: true, 0: false): " << child->is_grandparents(*Gerry, *Sue) << endl;
    return 0;
}